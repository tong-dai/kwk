//
//  ContentView.swift
//  interactive-ui
//
//  Created by Tong Dai on 4/29/24.
//

import SwiftUI

struct ContentView: View {
    @State private var name: String = ""
    @State private var age: String = ""
    @State private var showAlert: Bool = false

    var body: some View {
        VStack {
            Text("WHO ARE YOU?")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color.blue)
                .padding()
                .italic()
                

            TextField("enter your name here", text: $name)
                .multilineTextAlignment(.center)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("enter your age here", text: $age)
                .multilineTextAlignment(.center)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            

            Button("CLICK TO SUBMIT") {
                showAlert = true
            }
            .buttonStyle(.borderedProminent)
            .tint(.blue)
            .alert("WELCOME", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Hello, \(name)! You are \(age) years old.")
            }
        }
        .padding()
    }
}


#Preview {
    ContentView()
}
