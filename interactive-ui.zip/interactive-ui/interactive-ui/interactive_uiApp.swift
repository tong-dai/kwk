//
//  interactive_uiApp.swift
//  interactive-ui
//
//  Created by Tong Dai on 4/29/24.
//

import SwiftUI

@main
struct interactive_uiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
